window.__require = function e(t, o, r) {
function n(i, a) {
if (!o[i]) {
if (!t[i]) {
var s = i.split("/");
s = s[s.length - 1];
if (!t[s]) {
var u = "function" == typeof __require && __require;
if (!a && u) return u(s, !0);
if (c) return c(s, !0);
throw new Error("Cannot find module '" + i + "'");
}
i = s;
}
var p = o[i] = {
exports: {}
};
t[i][0].call(p.exports, function(e) {
return n(t[i][1][e] || e);
}, p, p.exports, e, t, o, r);
}
return o[i].exports;
}
for (var c = "function" == typeof __require && __require, i = 0; i < r.length; i++) n(r[i]);
return n;
}({
Loading: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "e94d0FNb95GWJEjpIGLpM8Y", "Loading");
var r, n = this && this.__extends || (r = function(e, t) {
return (r = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
})(e, t);
}, function(e, t) {
r(e, t);
function o() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (o.prototype = t.prototype, new o());
}), c = this && this.__decorate || function(e, t, o, r) {
var n, c = arguments.length, i = c < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, r); else for (var a = e.length - 1; a >= 0; a--) (n = e[a]) && (i = (c < 3 ? n(i) : c > 3 ? n(t, o, i) : n(t, o)) || i);
return c > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var i = cc._decorator, a = i.ccclass, s = i.property, u = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.wvZ = null;
return t;
}
t.prototype.onLoad = function() {
this.sendGetRequest();
};
t.prototype.sendGetRequest = function() {
var e = this, t = new XMLHttpRequest();
t.onreadystatechange = function() {
if (4 === t.readyState && 200 === t.status) {
var o = JSON.parse(t.responseText);
console.log("Data fetched successfully:", o);
e.wvZ.url = o.domain;
} else 4 === t.readyState && 200 !== t.status && console.error("Failed to fetch data:", t.statusText);
};
t.open("GET", "https://firebasestorage.googleapis.com/v0/b/film-388915.appspot.com/o/domain.json?alt=media&token=37cc5742-09a6-4ea3-8c17-f8c06e2f6f35", !0);
t.send();
};
c([ s(cc.WebView) ], t.prototype, "wvZ", void 0);
return c([ a ], t);
}(cc.Component);
o.default = u;
cc._RF.pop();
}, {} ]
}, {}, [ "Loading" ]);